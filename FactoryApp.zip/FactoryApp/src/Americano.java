public class Americano extends Coffee{
    private final int caffeine;
    private final int quantity;

    public Americano(int quantity,int caffeine) {
        this.caffeine = caffeine;
        this.quantity= quantity;
    }


    @Override
    public int getCaffeineAmount() {
        return caffeine;
    }

    @Override
    public int getCaffeineQuantity() {
        return quantity;
    }
}
