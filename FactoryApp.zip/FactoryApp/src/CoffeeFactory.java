public class CoffeeFactory {

    public static Coffee getCoffe(String type ,double caffeine,double quantity){
        if(type.equalsIgnoreCase("Espresso"))
            return new Espresso((int) quantity, (int) caffeine);
        else
        if(type.equalsIgnoreCase("Americano"))
            return new Americano((int) quantity, (int) caffeine);
        throw new RuntimeException("Coffee of "+type+" is not avaible");
    }

}
