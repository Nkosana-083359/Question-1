public class Main {
    public static void main(String[] args) {

        Coffee espresso = CoffeeFactory.getCoffe("Espresso",3,8);
        Coffee americano = CoffeeFactory.getCoffe("Americano",9,2);
        System.out.println(espresso.getCaffeineQuantity()+"mg of Espresso has "+
                        espresso.getCaffeineAmount()+"g caffeine ");
        System.out.println(americano.getCaffeineQuantity()+"mg of Americano has "+
                americano.getCaffeineAmount()+"g caffeine ");
    }
}