public abstract class Coffee {

    public abstract int getCaffeineAmount();
    public abstract int getCaffeineQuantity();


}
