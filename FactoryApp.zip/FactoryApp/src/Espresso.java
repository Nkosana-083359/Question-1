public class Espresso extends Coffee{
    private final int caffeine;
    private final int quantity;



    public Espresso(int quantity, int caffeine) {
        this.quantity = quantity;
        this.caffeine=caffeine;
    }

    @Override
    public int getCaffeineAmount() {
        return caffeine;
    }


    @Override
    public int getCaffeineQuantity() {
        return quantity;
    }
}
