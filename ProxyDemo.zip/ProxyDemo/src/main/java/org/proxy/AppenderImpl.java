package org.proxy;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

public class AppenderImpl implements Appender{
     public Connection con;

    public AppenderImpl(Connection con) {
        this.con = con;
    }

    public AppenderImpl() {
    }
    private  String dataBaseNAme="CityTBL";

    public String getDataBaseNAme() {
        return dataBaseNAme;
    }

    @Override
    public void joinString() throws SQLException {
        System.out.println("sent the string");
    }
}
