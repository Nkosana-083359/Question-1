package org.proxy;

public class Main {
    public static void main(String[] args)  {
        AppenderProxyImpl ab = new AppenderProxyImpl("Student","1226");
        try {
            ab.joinString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}