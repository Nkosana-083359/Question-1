package org.proxy;


import java.sql.SQLException;

public interface Appender {
    void joinString() throws SQLException;

}
