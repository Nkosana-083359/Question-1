package org.proxy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AppenderProxyImpl implements Appender{

    AppenderImpl appender;
    Boolean isAdmin;
    String password="1326";
    String userName="Nkosana";
    String dbURL="localhost:port/db";
    Connection con;
    String dbNAme="";
    String connectedString="";

    public AppenderProxyImpl(String username,String password) {
        if(username.equalsIgnoreCase("Student")&&password.equalsIgnoreCase("1226")){
            isAdmin=true;
        }
        appender = new AppenderImpl();


    }

    @Override
    public void joinString() throws SQLException {
       if(isAdmin){
           dbNAme=appender.getDataBaseNAme();
            connectedString=String.join("",dbURL,dbNAme);
           System.out.println("Database URL"+connectedString);
           //con= DriverManager.getConnection(connectedString,userName,password);
           //AppenderImpl connect = new AppenderImpl(con);

       }

    }
}
