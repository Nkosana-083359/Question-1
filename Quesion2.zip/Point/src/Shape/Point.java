/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Point {
    final int point;

    public Point() {
        this.point = 0;
    }

    public Point(int point) {
        this.point = point;
    }

    public int getPoint() {
        return point;
    }

    
}
