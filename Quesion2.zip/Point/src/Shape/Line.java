/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Line {
    
    Point point=new Point(0); 
    int pont=point.getPoint();
    Circle circle;
    double circleicum = circle.getCm();
    Triangle tri;
    double triPerimeter=tri.perimeter();
    
    Square square;
    double squarPerimeter= square.perimeter();
    Parallelogram para;
    double parPerimeter= para.perimeter();
    public double area(Point point,Line line){
        double area=0;
        return area;
    }
    
    public Line(int pont, double circleicum, double triPerimeter, double squarPerimeter, double length, double parPerimeter) {
        this.pont = pont;
        this.circleicum = circleicum;
        this.triPerimeter = triPerimeter;
        this.squarPerimeter = squarPerimeter;
        this.parPerimeter = parPerimeter;
        this.length = length;
    }
    
    double length ;

    public Line(double length) {
        this.length = length;
    }

    
    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }
    
}
