/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Rectangle {
    double l,b;

    public Rectangle(double l, double b) {
        this.l = l;
        this.b = b;
    }

    public double getL() {
        return l;
    }

    public void setL(double l) {
        this.l = l;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
    
     public double perimeter(){
       double  perimeter = l+l+b+b;
       return perimeter;
    }
}
