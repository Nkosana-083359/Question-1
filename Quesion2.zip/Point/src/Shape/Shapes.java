/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;



/**
 *
 * @author simphiwe
 */
public class Shapes {
    Line line;
    Circle circle;
    Triangle triangle;
    Square sqaure;
    Rectangle rectangle;
    Parallelogram parallegram;

    public Shapes() {
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Circle getCircle() {
        return circle;
    }

    public void setCircle(Circle circle) {
        this.circle = circle;
    }

    public Triangle getTriangle() {
        return triangle;
    }

    public void setTriangle(Triangle triangle) {
        this.triangle = triangle;
    }

    public Square getSqaure() {
        return sqaure;
    }

    public void setSqaure(Square sqaure) {
        this.sqaure = sqaure;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    public Parallelogram getParallegram() {
        return parallegram;
    }

    public void setParallegram(Parallelogram parallegram) {
        this.parallegram = parallegram;
    }

    public Shapes(Line line, Circle circle, Triangle triangle, Square sqaure, Rectangle rectangle, Parallelogram parallegram) {
        this.line = line;
        this.circle = circle;
        this.triangle = triangle;
        this.sqaure = sqaure;
        this.rectangle = rectangle;
        this.parallegram = parallegram;
    }
    
    
   
    
}
