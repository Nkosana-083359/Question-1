/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author simphiwe
 */
public class Circle {
    double cm;

    public Circle(double cm) {
        this.cm = cm;
    }
    
    public double getCm() {
        return cm;
    }

    public void setCm(double cm) {
        this.cm = cm;
    }
    
}
