/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author simphiwe
 */
public class Square {
    double s;

    public double getS() {
        return s;
    }

    public void setS(double s) {
        this.s = s;
    }

    public Square(double s) {
        this.s = s;
    }
    
     public double perimeter(){
       double  perimeter = s+s+s+s;
       return perimeter;
    }
}
