public class LoggerExample {
}
