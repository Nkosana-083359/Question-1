package org.single;

import java.util.logging.LogRecord;

import static java.util.logging.Level.INFO;
import static org.single.MyFormatter.getLoggerInstance;

public class AppleTV implements ScreenDisplay{
    public AppleTV() {
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public void display() {
        getLoggerInstance().logToConsole(new LogRecord(INFO,"This is Apple TV  "
        ), getClass().getCanonicalName());
    }
}
