package org.single;

public interface ScreenDisplay {
    void display();
}
