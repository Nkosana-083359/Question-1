package org.single;

import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class MyFormatter extends Formatter {


    private final static MyFormatter loggerInstance=new MyFormatter();


    public static MyFormatter getLoggerInstance() {
        return loggerInstance;
    }
    @Override
    public String format(LogRecord record)
    {
        record.setSourceClassName(this.getClass().getName());
        return record.getThreadID()+" ::Formatted in class "+record.getSourceClassName()+" :: "+new Date(record.getMillis())+"::"
                +record.getMessage()+"\n";
    }

    public void logToConsole(LogRecord record, String currentClass) {
        System.out.println("\n" + currentClass + "::" + this.format(record));
    }
}
