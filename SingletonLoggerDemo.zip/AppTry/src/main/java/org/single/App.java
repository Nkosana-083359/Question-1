package org.single;


import java.util.Scanner;

public class App
{
    public static void main( String[] args )

    {
        AppleTV appleTV = new AppleTV();
        PlasmaScreeen plasmaScreeen = new PlasmaScreeen();
        System.out.println("Select TV [AppleTV or PlasmaTV]");
        Scanner input = new Scanner(System.in);
        String option= input.nextLine();

        if(option.equalsIgnoreCase("AppleTV")) {
            appleTV.display();
        } else if (option.equalsIgnoreCase("PlasmaTV")) {
            plasmaScreeen.display();
        }


    }






    }

