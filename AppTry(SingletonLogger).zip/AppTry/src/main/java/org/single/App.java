package org.single;

import java.util.logging.LogRecord;

import static java.util.logging.Level.INFO;


public class App 
{
    public static void main( String[] args )

    {
        MyFormatter object= MyFormatter.getLoggerInstance();


        System.out.println(object.format(new LogRecord(INFO,"hello meet Prince" +
                " a skilled Java junior developer.")));

    }
}
