
package Project;

/**
 *
 * @author Nkosana Mdlalose
 */
public class TimeTable {
  enum Status{
      COMPLETED,ONGOING,PENDING;
  }

    
  
  public static void main(String [] args){
      Status[] values = Status.values();
      for(int x=0;x<3;x++){
          
            switch(values[x]){
                case COMPLETED:System.out.println("Congradulations you have completed your training at Enfint");
                break;
                case ONGOING:System.out.println("Trust the process");
                break;
                case PENDING:System.out.println("Processing ");
                break;
            }
      }
      
  }
  
  
  
  
  
}
