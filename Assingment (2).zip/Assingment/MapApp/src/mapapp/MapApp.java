/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mapapp;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author simphiwe
 */
public class MapApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        Map<String,String> employees = new HashMap<>();
        populateMap(employees);
        display(employees);
        seacrhEmployee(employees);
        
    }

    private static void populateMap(Map<String, String> employees) {
    
        employees.put("Manager"," Vuyi");
        employees.put("Administrator","Thato");
        employees.put("Registra"," Mlumba");
        
        
    }

   

    private static String display(Map<String, String> employees) {
    
        return employees.get("Administrator");
    }
    
     private static void seacrhEmployee(Map<String, String> employees) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
