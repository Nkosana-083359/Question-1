/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author simphiwe
 */
public class Triangle implements MyAbstract{
    int x,base,side1,side2,side3 ;

    public Triangle(int x, int base, int side1, int side2, int side3) {
        this.x = x;
        this.base = base;
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    public Triangle() {
    }
    
    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public int getSide1() {
        return side1;
    }

    public void setSide1(int side1) {
        this.side1 = side1;
    }

    public int getSide2() {
        return side2;
    }

    public void setSide2(int side2) {
        this.side2 = side2;
    }

    public int getSide3() {
        return side3;
    }

    public void setSide3(int side3) {
        this.side3 = side3;
    }

    @Override
    public int getPeremetere() {
    return side1+side2+side3;
    }
    
    
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.x;
        hash = 97 * hash + this.base;
        hash = 97 * hash + this.side1;
        hash = 97 * hash + this.side2;
        hash = 97 * hash + this.side3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Triangle other = (Triangle) obj;
        if (this.x != other.x) {
            return false;
        }
        if (this.base != other.base) {
            return false;
        }
        if (this.side1 != other.side1) {
            return false;
        }
        if (this.side2 != other.side2) {
            return false;
        }
        return this.side3 == other.side3;
    }
    
    
    
    
    @Override
    public int getArea() {
        return (int) (0.5*x*base);
    }

    @Override
    public int getX() {
    return x; 
    }

    @Override
    public void setX(int x) {
    this.x=x;
    }

    @Override
    public String toString() {
        return "Triangle{" + "x=" + x + ", base=" + base + ", side1=" + side1 + ", side2=" + side2 + ", side3=" + side3 + '}';
    }
    
}
