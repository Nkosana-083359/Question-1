/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author simphiwe
 */
public class Circle implements MyAbstract{
    int x=0;
    int radius;

    public Circle(int radius) {
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }
    @Override
    public int getArea() {
        return (int) (Math.PI*Math.pow(radius, 2));
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public void setX(int x) {
        this.x=x;
    }

    @Override
    public int getPeremetere() {
    return 0;
    }

    @Override
    public String toString() {
        return "Circle{" + "x=" + x + ", radius=" + radius + '}';
    }
    
}
