
package main;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Line implements MyAbstract{
     int x;

    public Line(int x) {
        this.x = x;
    }

    

    public Line() {
    }
    
    @Override
    public int getArea() {
        return 0;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public void setX(int x) {
        this.x=x;
    }

    @Override
    public int getPeremetere() {
    return x; 
    }

    @Override
    public String toString() {
        return "Line{" + "x=" + x + '}';
    }
    
}
