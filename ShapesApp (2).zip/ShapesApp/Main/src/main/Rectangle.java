
package main;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Rectangle implements MyAbstract{
    int length;
    int x;

    public Rectangle(int lenght, int width) {
        this.length = length;
        this.x = x;
    }

    public Rectangle() {
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.length;
        hash = 79 * hash + this.x;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Rectangle other = (Rectangle) obj;
        if (this.length != other.length) {
            return false;
        }
        return this.x == other.x;
    }
    
    
    
    public int getLenght() {
        return length;
    }

    public void setLenght(int length) {
        this.length = length;
    }

    
    
    
    
    @Override
    public int getArea() {
        return length*x;
    }

    @Override
    public int getX() {
    
    return x;
    }

    @Override
    public void setX(int x) {
    this.x=x;   
    }
    @Override
    public String toString() {
        return "Rectangle{" + "length=" + length + ", x=" + x + '}';
    }

    @Override
    public int getPeremetere() {
     return length+length+x+x ;}

    
}
