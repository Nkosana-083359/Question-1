
package main;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Parallelogram implements MyAbstract{
    int x,base,heigth;

    public Parallelogram() {
    }

    public Parallelogram(int x, int base, int heigth) {
        this.x = x;
        this.base = base;
        this.heigth = heigth;
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public int getHeigth() {
        return heigth;
    }

    public void setHeigth(int heigth) {
        this.heigth = heigth;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + this.x;
        hash = 23 * hash + this.base;
        hash = 23 * hash + this.heigth;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Parallelogram other = (Parallelogram) obj;
        if (this.x != other.x) {
            return false;
        }
        if (this.base != other.base) {
            return false;
        }
        return this.heigth == other.heigth;
    }

    

    

   
   
    
    @Override
    public int getPeremetere() {
     return 2*base+2*heigth; }
    
    @Override
    public int getArea() {
    return x*base;
    }

    @Override
    public int getX() {
        
        return x;
    }

    @Override
    public void setX(int x) {
    this.x=x;
    }

    @Override
    public String toString() {
        return "Parallelogram{" + "x=" + x + ", base=" + base + ", heigth=" + heigth + '}';
    }
    
}
