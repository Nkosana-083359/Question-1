
package main;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nkosana Mdlalose
 */


public class Main {

    public static void main(String[] args) {
        Sqaure sqaure = new Sqaure(5);
        
        Rectangle rectangle= new Rectangle();
        rectangle.setLenght(4);
        rectangle.setX(4);
        
        Triangle triangle = new Triangle(1,2,2,23,3);
        
       Parallelogram parallelogram = new Parallelogram(22,7,7);
       
       Point point = new Point();
       
       Line line = new Line(3);
       
       Circle circle = new Circle(9);
       
        System.out.println("----- Square area="+sqaure.getArea());
        System.out.println("----- Square perimeter"+sqaure.getPeremetere());
        
        System.out.println("       Rectangle arae="+ rectangle.getArea());
        System.out.println("----- Rectangle perimeter"+rectangle.getPeremetere());
        
         System.out.println("       Triangle arae="+ triangle.getArea());
        System.out.println("----- Triangle perimeter"+triangle.getPeremetere());
        
        System.out.println("       Parallelogram arae="+ parallelogram.getArea());
        System.out.println("----- Parallelogram perimeter="+parallelogram.getPeremetere());
        
        System.out.println("       Point arae="+ point.getArea());
        System.out.println("----- Point perimeter="+point.getArea());
        
         System.out.println("       Line arae="+ line.getArea());
        System.out.println("----- Line perimeter="+line.getPeremetere());
        
        System.out.println("       Circle arae="+ circle.getArea());
        System.out.println("----- Circle Circumference="+circle.getPeremetere());
        
        
        List<MyAbstract> shapeCollection = new ArrayList<>(List.of(sqaure,rectangle,triangle,parallelogram,point,line,circle));
        System.out.println("Shape collection"+shapeCollection);
        
    }
}
