
package main;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Point implements MyAbstract {
        final int x=0;

    

    public Point() {
    }
        
    @Override
    public int getArea() {
        return 0;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public void setX(int x) {
       
    }

    @Override
    public int getPeremetere() {
    return 0;
    }

    @Override
    public String toString() {
        return "Point{" + "x=" + x + '}';
    }
    
}
