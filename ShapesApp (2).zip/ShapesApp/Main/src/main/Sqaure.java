
package main;

import java.util.Objects;

/**
 *
 * @author Nkosana Mdlalose
 */
public class Sqaure implements MyAbstract {
    private int x;
    

    
    
    
   

    
    
    public Sqaure(int x) {
        this.x = x;
    }

    public Sqaure() {
        this.x = 0;
       
        
    }
    
   
    @Override
    public int getArea() {
         return x*x;
    }

    @Override
    public int getX() {
    return x;
    }

    @Override
    public void setX(int x) {
       this.x=x; //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public int hashCode() {
        
        return Objects.hash(x);
}

    @Override
    public boolean equals(Object obj) {
        if(obj==this)return true;
       
        if(obj==null||getClass() != obj.getClass()) return false;
        Sqaure figure = (Sqaure)obj;
        return x == figure.x;
    }

   

    

    
    
        
    @Override
    public String toString() {
        return "My Square{" + "x=" + x + '}'+"\n";
    }

    @Override
    public int getPeremetere() {
        return x*4;
    }
    
    
    
    
}
