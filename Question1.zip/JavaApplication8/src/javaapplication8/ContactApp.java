
package javaapplication8;

//import java.util.Scanner;

import java.util.Scanner;


/**
 *
 * @author Nkosana Mdlalose
 */
public class ContactApp {

    public static void main(String[] args) {
        Scanner in =new Scanner(System.in);
        int op = getOption();
        Contact contact;
        Contact [] contacts = new Contact[100];
        
        String charact ;
        
        int counter=0;
        String name ;
        while(op!=4){
            switch(op){
                case 1: contact= getContact();
                        contacts[counter]=contact;
                            counter++;
                            break;
                   
                case 2: name=getName();
                        search(contacts, name);
                        break;
                        
                case 3:
                            charact = getString();
                            
                            getByStrings(contacts,charact);
                break;
                default:System.out.println("System Closed");
                        
                
            }
            op = getOption();
        }
        
        
        
        
        
        
    }

    private static void search(Contact[] conta, String name) {

        for (Contact conta1 : conta) {
            if (conta1.getName().equalsIgnoreCase(name)) {
                
                System.out.println("name:" + conta1.getName() + "\n" + "phone number:" + conta1.getPhoneNumber()+"\n");
                break;
            }else{
                System.out.println("null");
            }

        }
    }

    private static void getByStrings(Contact[] conta, String charact) {
        System.out.println("*****CONTACT LIST*****");
        for (Contact conta1 : conta) {
                if(conta1.getName().endsWith(charact)){
                            System.out.println("name:" + conta1.getName() + "\n" + "  phone number:" + conta1.getPhoneNumber());
                }
        }
    }

    private static int getOption() {
            Scanner in =new Scanner(System.in);
            System.out.println("1:add"+"\n"+"2:search"+"\n"+"3:display contact that ends with your specfied character  "+"\n"+"4:stop");
            int op = in.nextInt();
            return op;
    }

    private static Contact getContact() {
         Scanner in =new Scanner(System.in);
         System.out.println("Enter name:");
         String name = in.nextLine();
         System.out.println("Enter phone Number:");
         String phoneNum= in.nextLine();
         Contact contact = new Contact(name,phoneNum);
         return contact;
    }

    private static String getName() {
    Scanner in =new Scanner(System.in);
         System.out.println("Enter name:");
         String name = in.nextLine();
         return name;
    }

    private static String getString() {
     
        Scanner in = new Scanner(System.in);
        System.out.println("Enter search String");
        String str = in.nextLine();
        return str;
    }

    
        
    }

    

